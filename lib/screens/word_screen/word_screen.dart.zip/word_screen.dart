import 'dart:developer';
import 'dart:io';

// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:litelearninglab/common_widgets/boom_menu.dart';
import 'package:litelearninglab/common_widgets/boom_menu_item.dart' as bm;
import 'package:litelearninglab/common_widgets/spacings.dart';
import 'package:litelearninglab/constants/all_assets.dart';
import 'package:litelearninglab/constants/app_colors.dart';
import 'package:litelearninglab/constants/keys.dart';
import 'package:litelearninglab/database/WordsDatabaseRepository.dart';
import 'package:litelearninglab/database/databaseProvider.dart';
import 'package:litelearninglab/models/ProLab.dart';
import 'package:litelearninglab/models/Word.dart';
import 'package:litelearninglab/screens/dialogs/own_word_dialog.dart';
import 'package:litelearninglab/screens/dialogs/speech_analytics_dialog.dart';
import 'package:litelearninglab/screens/profluent_english/profluent_english_screen.dart';
import 'package:litelearninglab/screens/word_screen/widgets/drop_down_word_item.dart';
import 'package:litelearninglab/screens/word_screen/widgets/word_menu.dart';
import 'package:litelearninglab/utils/bottom_navigation.dart';
import 'package:litelearninglab/utils/encrypt_data.dart';
import 'package:litelearninglab/utils/firebase_helper_RTD.dart';
import 'package:litelearninglab/utils/shared_pref.dart';
import 'package:litelearninglab/utils/sizes_helpers.dart';
import 'package:litelearninglab/utils/utils.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:scroll_to_index/scroll_to_index.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../common_widgets/background_widget.dart';
import '../../states/auth_state.dart';
import '../../utils/audio_player_manager.dart';
import '../../utils/firebase_helper.dart';
import '../profluent_english/new_profluent_english_screen.dart';

enum PlayingRouteState { speakers, earpiece }

bool isAllPlaying3 = false;
bool isAllPlaying = false;

class WordScreen extends StatefulWidget {
  WordScreen({
    Key? key,
    required this.title,
    required this.load,
    this.word,
    this.filterLoad,
  }) : super(key: key);
  final String title;
  final String load;
  final ProLab? word;
  final String? filterLoad;

  @override
  _WordScreenState createState() {
    return _WordScreenState();
  }
}

class _WordScreenState extends State<WordScreen> with TickerProviderStateMixin, WidgetsBindingObserver {
  final db = new FirebaseHelperRTD();
  FirebaseHelper _firestore = new FirebaseHelper();
  bool openPlay3StopDialog = false;
  bool openPlay1StopDialog = false;
  bool _isPaused = false;
  int _currentIndex = 0;
  bool _isPaused3 = false;
  int _currentPlayCount3 = 0;
  int _currentIndex3 = 0;
  int _pausedPosition = 0;

  List<Word> _words = [];
  final _searchQueryController = TextEditingController();
  bool _isSearching = false;
  bool _isLoading = false;
  bool _isCorrect = false;
  String _selectedWord = "";
  String? _selectedWordOnClick;
  bool open = false;
  final Map<String, GlobalKey> _itemKeys = {};

  late AutoScrollController controller;

  final _audioPlayerManager = AudioPlayerManager();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    controller = AutoScrollController(
        viewportBoundaryGetter: () => Rect.fromLTRB(0, 0, 0, MediaQuery.of(context).padding.bottom),
        axis: Axis.vertical);

    _getWords(isRefresh: false);
  }

  void didChangeDependencies() {
    super.didChangeDependencies();
    getIsSplit(context);
    setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.resumed:
        print("app in resumed");
        break;
      case AppLifecycleState.inactive:
        print("app in inactive");
        _audioPlayerManager.stop();
        break;
      case AppLifecycleState.paused:
        print("app in paused");
        _audioPlayerManager.stop();
        break;
      case AppLifecycleState.detached:
        print("app in detached");
        _audioPlayerManager.stop();
        break;
      case AppLifecycleState.hidden:
        break;
    }
  }

  Future toggleWordFavorite(String? eLocalPath1, Word word) async {
    DatabaseProvider dbb = DatabaseProvider.get;
    WordsDatabaseRepository dbRef = WordsDatabaseRepository(dbb);
    await dbRef.setFav(word.id!, 1, eLocalPath1!);
    setState(() {
      word.isFav = 1;
    });
  }

  Future<void> addInitialFav() async {
    try {
      Directory appDocDir = await getApplicationDocumentsDirectory();
      String appDocPath = appDocDir.path;
      String? localPath1;
      String? eLocalPath1;
      for (var i = 0; i < 5; i++) {
        localPath1 =
        await Utils.downloadFile(context, _words[i].file!, '${_words[i].text}.mp3', '$appDocPath/${widget.load}');
        eLocalPath1 = EncryptData.encryptFile(localPath1, context);
        try {
          await File(localPath1).delete();
        } catch (e) {}
        await toggleWordFavorite(eLocalPath1, _words[i]);
      }
    } catch (e) {}
  }

//ending of intial fav addition
  Future<bool> _isFirstTimeUser(String userId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getBool('isFirstTime_$userId') ?? true;
  }

  Future<void> _setFirstTimeFlag(String userId, bool isFirstTime) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isFirstTime_$userId', isFirstTime);
  }

  Future<void> _checkAndPerformInitialFav() async {
    String userId = await SharedPref.getSavedString('userId');
    bool isFirstTime = await _isFirstTimeUser(userId);
    if (isFirstTime) {
      await addInitialFav();
      setState(() {
        // isfirst = false;
      });
      await _setFirstTimeFlag(userId, false);
    }
  }

  void _getWords({String? searchTerm, required bool isRefresh}) async {
    print("getwordsscalleddddddd>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
    print("searchTerm: ${searchTerm}");
    _isLoading = true;
    if ((searchTerm == null || searchTerm.length == 0) && !isRefresh) setState(() {});
    _words = [];
    if (widget.load.length > 0) {
      _words = await db.getWords(widget.load);
      isPlaying = List.generate(_words.length, (index) => false.obs);
      // isPlaying = List.generate(_words.length, (index) => false);
      print('list first item from local:${_words.first.localPath}');

      await _checkAndPerformInitialFav();
    } else {
      DatabaseProvider dbb = DatabaseProvider.get;
      WordsDatabaseRepository dbRef = WordsDatabaseRepository(dbb);
      List<Word> words = await dbRef.getWords();
      isPlaying = List.generate(_words.length, (index) => false.obs);
      // isPlaying = List.generate(_words.length, (index) => false);
      for (Word wr in words) {
        if ((wr.isFav == 1 && widget.filterLoad == null) ||
            (wr.isFav == 1 && widget.filterLoad != null && widget.filterLoad == wr.cat)) {
          _words.add(wr);
        }
      }
    }

    if (searchTerm != null && searchTerm.length > 0) {
      _words = _words.where((element) => element.text!.toLowerCase().contains(searchTerm.toLowerCase())).toList();
    }
    if (widget.word != null) _selectedWordOnClick = widget.word?.id;
    _isLoading = false;
    if (mounted) setState(() {});

    if (widget.word != null) {
      await controller.scrollToIndex(_words.indexWhere((element) => element.text == widget.word?.id),
          preferPosition: AutoScrollPosition.begin);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _searchQueryController.dispose();
    _audioPlayerManager.dispose();
    isAllPlaying3 = false;
    isAllPlaying = false;
    super.dispose();
  }

  Widget _buildSearchField() {
    return Center(
      child: Padding(
        padding: EdgeInsets.only(bottom: 5, left: 45),
        child: TextField(
          controller: _searchQueryController,
          autofocus: true,
          decoration: InputDecoration(
            hintText: "Search Word...",
            border: InputBorder.none,
            hintStyle: TextStyle(color: Colors.white),
          ),
          style: TextStyle(color: Colors.white, fontSize: 16.0),
          onChanged: (query) {
            _getWords(searchTerm: query, isRefresh: false);
          },
        ),
      ),
    );
  }

  void updateSearchQuery(String newQuery) {
    _getWords(searchTerm: newQuery, isRefresh: false);
  }

  List<Widget> _buildActions() {
    if (_isSearching) {
      return <Widget>[
        Spacer(),
        IconButton(
          icon: ImageIcon(AssetImage(AllAssets.pfSearch)),
          onPressed: () {
            if (_searchQueryController.text.isEmpty) {
              Navigator.pop(context);
              return;
            }
            _getWords(searchTerm: _searchQueryController.text, isRefresh: false);
          },
        ),
        SPW(displayWidth(context) / 37.5)
      ];
    }

    return <Widget>[
      if (widget.title.trim() == "Priority List" && !isAllPlaying3 ||
          widget.title.trim() == "All Priority List" && !isAllPlaying3)
        IconButton(
            icon: Image.asset(
              "assets/images/play_3new.png",
              width: 25,
            ),
            onPressed: () {
              print("sdjfijfiwjeifrjei");
              _audioPlayerManager.stop();
              isAllPlaying = false;

              setState(() {
                print("playall3333");
                openPlay3StopDialog = true;
                _currentIndex3=0;
                _currentPlayCount3=0;
                print("openStopDialog:$openPlay3StopDialog");
              });
              _playAll3Times();
            }),
      /*if (openStopDialog = true)
        Stack(
          children: [
            Positioned(
              child: IconButton(onPressed: () {}, icon: Icon(Icons.stop)),
            ),
          ],
        ),*/
      if (widget.title.trim() == "Priority List" && isAllPlaying3 ||
          widget.title.trim() == "All Priority List" && isAllPlaying3)
        IconButton(
          icon: Image.asset(
            "assets/images/play_3new.png",
            width: 25,
          ),
          onPressed: () {
            _audioPlayerManager.stop();
            isAllPlaying3 = false;
            setState(() {});
          },
        ),
      if (widget.title.trim() == "Priority List" && !isAllPlaying ||
          widget.title.trim() == "All Priority List" && !isAllPlaying)
        IconButton(
          icon: Image.asset(
            "assets/images/play_1new.png",
            width: 25,
          ),
          onPressed: () {
            print("stop button clicked>>>>>>>>>>>>>>>>>>>>>");
            _audioPlayerManager.stop();
            isAllPlaying = false;
           // isAllPlaying3 = false;
            setState(() {
              openPlay1StopDialog = true;
              _currentIndex=0;
              _isPaused=false;

            });
            _playAll();
          },
        ),
      if (widget.title.trim() == "Priority List" && isAllPlaying ||
          widget.title.trim() == "All Priority List" && isAllPlaying)
        IconButton(
          icon: Image.asset(
            "assets/images/play_1new.png",
            width: 25,
          ),
          onPressed: () {
            log("pause button clicked>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            /*     _audioPlayerManager.stop();
            isAllPlaying = false;*/
            setState(() {});
          },
        ),
      IconButton(
        icon: ImageIcon(AssetImage(AllAssets.searchIcon)),
        onPressed: _startSearch,
      ),
      SPW(displayWidth(context) / 37.5)
    ];
  }

  void _startSearch() {
    ModalRoute.of(context)?.addLocalHistoryEntry(LocalHistoryEntry(onRemove: _stopSearching));

    setState(() {
      _isSearching = true;
    });
  }

  void _stopSearching() {
    _clearSearchQuery();

    setState(() {
      _isSearching = false;
    });
  }

  void _clearSearchQuery() {
    setState(() {
      _searchQueryController.clear();
      updateSearchQuery("");
    });
  }

  void _scrollToItem(int index) {
    final double itemHeight = 200.0; // Adjust based on your item height
    final position = index * itemHeight;
    final viewportHeight = controller.position.viewportDimension;
    final offset = controller.offset;

    if (position < offset || position + itemHeight > offset + viewportHeight) {
      controller.animateTo(
        position,
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOut,
      );
    }
  }

  void _showDialog(String word, bool notCatch, BuildContext context) async {
    // log("message");
    Get.dialog(
      Container(
        child: Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25.0)),
          child: SpeechAnalyticsDialog(
            true,
            isShowDidNotCatch: notCatch,
            word: word,
            title: widget.title,
            load: widget.load,
          ),
        ),
      ),
    ).then((value) {
      if (value != null && value.isCorrect == "true" || value.isCorrect == "false") {
        _selectedWord = word;
        _isCorrect = value.isCorrect == "true" ? true : false;
        setState(() {});
      } else if (value != null && value.isCorrect == "notCatch") {
        _showDialog(word, true, context);
      } else if (value != null && value.isCorrect == "openDialog") {
        _showDialog(word, false, context);
      }
    }).onError((error, stackTrace) {
      log(error.toString());
    });
  }

  void _playAll() async {
    isAllPlaying = true;
    String? eLocalPath;
    AuthState userDatas = Provider.of<AuthState>(context, listen: false);
    setState(() {});
    isPlaying = List.generate(_words.length, (index) => false.obs);

    for (int i = _currentIndex; i < _words.length; i++) {
      print("Current Index: $i");


      if (_isPaused) {
        print("ispaused:${_isPaused}");
        _currentIndex = i;
        print("Paused at index: $_currentIndex");
        return;
        //break;
      }

      if (isAllPlaying && _words[i].file != null && _words[i].file!.isNotEmpty) {
        _words[i].isPlaying = true;
        isPlaying[i].value = true;
        setState(() {});
        await _audioPlayerManager.play(_words[i].file!, context: context, localPath: _words[i].localPath,
            decodedPath: (val) {
              eLocalPath = val;
            });

        await Future.delayed(Duration(seconds: 2));
        _words[i].isPlaying = false;
        isPlaying[i].value = false;

        if (eLocalPath != null && eLocalPath!.isNotEmpty) {
          try {
            File(eLocalPath!).delete();
          } catch (e) {}
        }

        _firestore.saveWordListReport(
          isPractice: false,
          company: userDatas.appUser!.company!,
          name: userDatas.appUser!.UserMname,
          userID: userDatas.appUser!.id!,
          word: widget.title,
          team: userDatas.appUser?.team,
          userprofile: userDatas.appUser?.profile,
          city: userDatas.appUser?.city,
          load: widget.load,
          title: widget.title,
          time: 1,
          date: DateFormat('dd-MMM-yyyy').format(DateTime.now()),
        );
      }
    }
    if (!_isPaused) {
      _currentIndex = 0;
      isAllPlaying = false;
      setState(() {});
    }
  }

  void pauseAll() {
    if (isAllPlaying) {
      print("Pause called");
      _audioPlayerManager.pause();
      setState(() {
        _isPaused = true;
      });
      isAllPlaying = false;
    }
  }

  void resumeAll() {
    if (_isPaused) {
      print("Resume function called");
      _audioPlayerManager.resume();
      _isPaused = false;
      isAllPlaying = true;
      _playAll();
    }
  }

  void _playAll3Times() async {
    log("three playing switch clicked>>>>>>>>>>>>>>>>>>>>>>>>>>>");
    isAllPlaying3 = true;
    String? eLocalPath;
    AuthState userDatas = Provider.of<AuthState>(context, listen: false);
    isPlaying = List.generate(_words.length, (index) => false.obs);

    for (int i = _currentIndex3; i < _words.length; i++) {
      if (!isAllPlaying3) break;

      if (_words[i].file != null && _words[i].file!.isNotEmpty) {
        for (int j = _currentPlayCount3; j < 3; j++) {
          print("jloooppppppppppppppp");
          if (!isAllPlaying3) {
            _currentIndex3 = i;
            _currentPlayCount3 = j;
            print("Paused at index: $_currentIndex3, play count: $_currentPlayCount3");
            return;
          }

          if (_isPaused3) {
            print("sjaoijdifjiwjr");
            _currentIndex3 = i;
            _currentPlayCount3 = j;
            print("Paused at index: $_currentIndex3, play count: $_currentPlayCount3");
            return;
          }

          log("Playing word at index: $i, play count: $j");
          _words[i].isPlaying = true;
          isPlaying[i].value = true;
          setState(() {});

          await _audioPlayerManager.play3(
            _words[i].file!,
            context: context,
            localPath: _words[i].localPath,
            decodedPath: (val) {
              eLocalPath = val;
            },
          );

          await Future.delayed(Duration(seconds: 2));
          _words[i].isPlaying = false;
          isPlaying[i].value = false;

          if (eLocalPath != null && eLocalPath!.isNotEmpty) {
            try {
              File(eLocalPath!).delete();
            } catch (e) {
              log("Failed to delete file: $e");
            }
          }

          _firestore.saveWordListReport(
            isPractice: false,
            company: userDatas.appUser!.company!,
            name: userDatas.appUser!.UserMname,
            userID: userDatas.appUser!.id!,
            word: widget.title,
            team: userDatas.appUser?.team,
            userprofile: userDatas.appUser?.profile,
            city: userDatas.appUser?.city,
            load: widget.load,
            title: widget.title,
            time: 1,
            date: DateFormat('dd-MMM-yyyy').format(DateTime.now()),
          );
        }
        _currentPlayCount3 = 0;
      }
    }

    if (!_isPaused3) {
      _currentIndex3 = 0;
      _currentPlayCount3 = 0;
      isAllPlaying3 = false;
      setState(() {});
    }
  }

  void pauseAll3() {
    if (isAllPlaying3) {
      print("Pause called");
      _audioPlayerManager.pause();
      _isPaused3 = true;
      isAllPlaying3 = false;
      setState(() {});
    }
  }

  void resumeAll3() {
    if (_isPaused3) {
      print("Resume function called");
      _audioPlayerManager.resume();
      _isPaused3 = false;
      isAllPlaying3 = true;
      _playAll3Times();
    }
  }

  /*void _playAll3Times() async {
    log("three playing switch clicked>>>>>>>>>>>>>>>>>>>>>>>>>>>");
    isAllPlaying3 = true;
    String? eLocalPath;
    AuthState userDatas = Provider.of<AuthState>(context, listen: false);
    setState(() {});
    isPlaying = List.generate(_words.length, (index) => false.obs);
    for (int i = 0; i < _words.length; i++) {
      if (isAllPlaying3 == true) {
        if (isAllPlaying3 && _words[i].file != null && _words[i].file!.isNotEmpty) {
          for (int j = 0; j < 3; j++) {
            if (isAllPlaying3 == true) {
              log("*****$i*********");
              _words[i].isPlaying = true;
              isPlaying[i].value = true;
              // isPlaying[i].refresh();
              log("${isPlaying.length} ${_words.length}  ${isPlaying[i].value}");
              setState(() {});

              await _audioPlayerManager.play3(_words[i].file!, context: context, localPath: _words[i].localPath,
                  decodedPath: (val) {
                    eLocalPath = val;
                  });
              await Future.delayed(Duration(seconds: 2));
              _words[i].isPlaying = false;
              isPlaying[i].value = false;
              if (eLocalPath != null && eLocalPath!.isNotEmpty) {
                try {
                  File(eLocalPath!).delete();
                } catch (e) {}
              }

              */ /* if (eLocalPath != null && eLocalPath!.isNotEmpty) {
                await Future.delayed(Duration(seconds: 3));
              } */ /*

              _firestore.saveWordListReport(
                  isPractice: false,
                  company: userDatas.appUser!.company!,
                  name: userDatas.appUser!.UserMname,
                  userID: userDatas.appUser!.id!,
                  word: widget.title,
                  team: userDatas.appUser?.team,
                  userprofile: userDatas.appUser?.profile,
                  city: userDatas.appUser?.city,
                  load: widget.load,
                  title: widget.title,
                  time: 1,
                  date: DateFormat('dd-MMM-yyyy').format(DateTime.now()));
            } else {
              break;
            }
          }
        }
      } else {
        break;
      }
    }
    isAllPlaying3 = false;
    setState(() {});
  }*/

  updateThreePlayerFlag() {
    log("working the threeplayer switch>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
    isAllPlaying3 = false;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return BackgroundWidget(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            icon: Icon(
              Icons.arrow_back_ios_new_rounded,
            ),
          ),
          flexibleSpace: !_isSearching
              ? Padding(
            padding: EdgeInsets.only(left: getWidgetWidth(width: 50)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: displayWidth(context) / 1.4,
                  child: Text(
                    widget.title,
                    maxLines: 1,
                    style: TextStyle(
                        fontFamily: Keys.fontFamily,
                        fontSize: globalFontSize(18, context),
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        overflow: TextOverflow.ellipsis),
                  ),
                ),
              ],
            ),
          )
              : _buildSearchField(),
          iconTheme: IconThemeData(color: Colors.white),
          centerTitle: false,
          actions: _buildActions(),
          backgroundColor: Color(0xFF324265),
        ),
        body:
        //  _isConnected == false
        //     ? Center(
        //         child: Text(
        //           "No Network Connection",
        //           style: TextStyle(
        //               color: AppColors.white, fontFamily: Keys.fontFamily),
        //         ),
        //       )
        //     :
        _words.length == 0 && !_isLoading
            ? Column(
          children: [
            Expanded(
              child: Center(
                child: Text(
                  "Not Found",
                  style: TextStyle(color: AppColors.white, fontFamily: Keys.fontFamily),
                ),
              ),
            ),
            Container(
              height: isSplitScreen ? getFullWidgetHeight(height: 60) : getWidgetHeight(height: 60),
              width: kWidth,
              decoration: BoxDecoration(
                color: Color(0xFF34445F),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton(
                      icon: ImageIcon(
                        AssetImage(AllAssets.bottomHome),
                        color: context.read<AuthState>().currentIndex == 0
                            ? Color(0xFFAAAAAA)
                            : Color.fromARGB(132, 170, 170, 170),
                      ),
                      onPressed: () {
                        context.read<AuthState>().changeIndex(0);
                        Navigator.pushReplacement(
                            context, MaterialPageRoute(builder: (context) => BottomNavigation()));
                      }),
                  IconButton(
                      icon: ImageIcon(AssetImage(AllAssets.bottomPL),
                          color: context.read<AuthState>().currentIndex == 1
                              ? Color(0xFFAAAAAA)
                              : Color.fromARGB(132, 170, 170, 170)),
                      onPressed: () {
                        context.read<AuthState>().changeIndex(1);
                        Navigator.pushReplacement(
                            context, MaterialPageRoute(builder: (context) => BottomNavigation()));
                      }),
                  IconButton(
                      icon: ImageIcon(AssetImage(AllAssets.bottomIS),
                          color: context.read<AuthState>().currentIndex == 2
                              ? Color(0xFFAAAAAA)
                              : Color.fromARGB(132, 170, 170, 170)),
                      onPressed: () {
                        context.read<AuthState>().changeIndex(2);
                        Navigator.pushReplacement(
                            context, MaterialPageRoute(builder: (context) => BottomNavigation()));
                      }),
                  IconButton(
                      icon: ImageIcon(AssetImage(AllAssets.bottomPE),
                          color: context.read<AuthState>().currentIndex == 3
                              ? Color(0xFFAAAAAA)
                              : Color.fromARGB(132, 170, 170, 170)),
                      onPressed: () {
                        context.read<AuthState>().changeIndex(3);
                        Navigator.pushReplacement(
                            context, MaterialPageRoute(builder: (context) => BottomNavigation()));
                      }),
                  IconButton(
                      icon: ImageIcon(AssetImage(AllAssets.bottomPT),
                          color: context.read<AuthState>().currentIndex == 4
                              ? Color(0xFFAAAAAA)
                              : Color.fromARGB(132, 170, 170, 170)),
                      onPressed: () {
                        context.read<AuthState>().changeIndex(4);
                        Navigator.pushReplacement(
                            context, MaterialPageRoute(builder: (context) => BottomNavigation()));
                      }),
                ],
              ),
            )
          ],
        )
            : _isLoading
            ? Center(child: CircularProgressIndicator())
            : Column(
          children: [
            Expanded(
              child: Stack(
                children: [
                  ListView.builder(
                      padding: EdgeInsets.only(
                          top: isSplitScreen
                              ? getFullWidgetHeight(height: 10)
                              : getWidgetHeight(height: 10)),
                      itemCount: _words.length,
                      controller: controller,
                      itemBuilder: (BuildContext context, int index) {
                        if (!isAllPlaying && !isAllPlaying3) {
                          print("checkkkkkkkkkkkkkkkkkkk");
                          isPlaying = List.generate(_words.length, (index) => false.obs);
                          //_getWords(isRefresh: false);
                        }
                        return AutoScrollTag(
                          key: ValueKey(_words[index].text),
                          controller: controller,
                          index: index,
                          child: Padding(
                            padding: EdgeInsets.only(
                                bottom: index == _words.length - 1
                                    ? isSplitScreen
                                    ? getFullWidgetHeight(height: 60)
                                    : getWidgetHeight(height: 60)
                                    : 0),
                            child: DropDownWordItem(
                              localPath: _words[index].localPath,
                              load: widget.load,
                              length: _words.length,
                              index: index,
                              // isPlaying: _words[index].isPlaying,
                              isDownloaded:
                              _words[index].localPath != null && _words[index].localPath!.isNotEmpty,
                              maintitle: widget.title,
                              onExpansionChanged: (val) {
                                print("check1111111111111111111111111>");
                                setState(() {
                                  _selectedWord = '';
                                });
                                if (val) {
                                  _selectedWordOnClick = _words[index].text;
                                  setState(() {});
                                  if (_words.length - 2 <= index) {
                                    WidgetsBinding.instance.addPostFrameCallback((_) {
                                      _scrollToItem(index);
                                    });
                                    // controller.animateTo(
                                    //   controller.position.maxScrollExtent,
                                    //   duration: const Duration(milliseconds: 100),
                                    //   curve: Curves.linear,
                                    // );
                                  }
                                }
                              },
                              initiallyExpanded: _selectedWordOnClick != null &&
                                  _selectedWordOnClick == _words[index].text,
                              isWord: true,
                              isRefresh: (val) {
                                if (val) _getWords(isRefresh: true);
                              },
                              // words: _words,
                              wordId: _words[index].id!,
                              isFav: _words[index].isFav!,
                              title: _words[index].text!,
                              url: _words[index].file,
                              onTapForThreePlayerStop: updateThreePlayerFlag,
                              children: [
                                WordMenu(
                                  pronun: _words[index].pronun!,
                                  selectedWord: _selectedWord,
                                  isCorrect: _selectedWord == _words[index].text && _isCorrect,
                                  text: _words[index].text!,
                                  syllables: _words[index].syllables!,
                                  onTapHeadphone: () async {},
                                  onTapMic: () async {
                                    _showDialog(_words[index].text!, false, context);
                                  },
                                )
                              ],
                            ),
                          ),
                        );
                      }),
                  openPlay3StopDialog
                      ? Positioned(
                      right: 120,
                      top: 5,
                      child: Container(
                        height: isSplitScreen
                            ? getFullWidgetHeight(height: 45)
                            : getWidgetHeight(height: 45),
                        width: getWidgetWidth(width: 100),
                        decoration: BoxDecoration(
                            color: Colors.white, borderRadius: BorderRadius.circular(20)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            !isAllPlaying3
                                ? IconButton(
                                onPressed: () {
                                  resumeAll3();
                                },
                                icon: Icon(Icons.play_arrow, color: Color(0XFF34425D), size: 30))
                                : IconButton(
                                onPressed: () {
                                  pauseAll3();
                                },
                                icon: Icon(Icons.pause, color: Color(0XFF34425D), size: 30)),
                            IconButton(
                                onPressed: () {
                                  _audioPlayerManager.stop();
                                  isAllPlaying3 = false;
                                  setState(() {
                                    openPlay3StopDialog = false;
                                  });
                                },
                                icon: Icon(
                                  Icons.stop,
                                  color: Color(0XFF34425D),
                                  size: 30,
                                )),
                          ],
                        ),
                      ))
                      : openPlay1StopDialog
                      ? Positioned(
                      right: 120,
                      top: 5,
                      child: Container(
                        height: isSplitScreen
                            ? getFullWidgetHeight(height: 45)
                            : getWidgetHeight(height: 45),
                        width: getWidgetWidth(width: 100),
                        decoration: BoxDecoration(
                            color: Colors.white, borderRadius: BorderRadius.circular(20)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            _isPaused
                                ? IconButton(
                                onPressed: () {
                                  print("ClickedResumeAllllll>>>>>");
                                  resumeAll();
                                },
                                icon: Icon(Icons.play_arrow,
                                    color: Color(0XFF34425D), size: 30))
                                : IconButton(
                                onPressed: () {
                                  print("ClickedPauseAlll>>>>>>>>");
                                  pauseAll();
                                },
                                icon: Icon(
                                  Icons.pause,
                                  color: Color(0XFF34425D),
                                  size: 30,
                                )),
                            IconButton(
                                onPressed: () {
                                  _audioPlayerManager.stop();
                                  setState(() {
                                    isAllPlaying = false;
                                    openPlay1StopDialog = false;
                                  });
                                },
                                icon: Icon(
                                  Icons.stop,
                                  color: Color(0XFF34425D),
                                  size: 30,
                                )),
                          ],
                        ),
                      ))
                      : SizedBox()
                ],
              ),
            ),
            Container(
              height: isSplitScreen ? getFullWidgetHeight(height: 60) : getWidgetHeight(height: 60),
              width: kWidth,
              decoration: BoxDecoration(
                color: Color(0xFF34445F),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton(
                      icon: ImageIcon(
                        AssetImage(AllAssets.bottomHome),
                        color: context.read<AuthState>().currentIndex == 0
                            ? Color(0xFFAAAAAA)
                            : Color.fromARGB(132, 170, 170, 170),
                      ),
                      onPressed: () {
                        context.read<AuthState>().changeIndex(0);
                        Navigator.pushReplacement(
                            context, MaterialPageRoute(builder: (context) => BottomNavigation()));
                      }),
                  IconButton(
                      icon: ImageIcon(AssetImage(AllAssets.bottomPL),
                          color: context.read<AuthState>().currentIndex == 1
                              ? Color(0xFFAAAAAA)
                              : Color.fromARGB(132, 170, 170, 170)),
                      onPressed: () {
                        context.read<AuthState>().changeIndex(1);
                        Navigator.pushReplacement(
                            context, MaterialPageRoute(builder: (context) => BottomNavigation()));
                      }),
                  IconButton(
                      icon: ImageIcon(AssetImage(AllAssets.bottomIS),
                          color: context.read<AuthState>().currentIndex == 2
                              ? Color(0xFFAAAAAA)
                              : Color.fromARGB(132, 170, 170, 170)),
                      onPressed: () {
                        context.read<AuthState>().changeIndex(2);
                        Navigator.pushReplacement(
                            context, MaterialPageRoute(builder: (context) => BottomNavigation()));
                      }),
                  IconButton(
                      icon: ImageIcon(AssetImage(AllAssets.bottomPE),
                          color: context.read<AuthState>().currentIndex == 3
                              ? Color(0xFFAAAAAA)
                              : Color.fromARGB(132, 170, 170, 170)),
                      onPressed: () {
                        context.read<AuthState>().changeIndex(3);
                        Navigator.pushReplacement(
                            context, MaterialPageRoute(builder: (context) => BottomNavigation()));
                      }),
                  IconButton(
                      icon: ImageIcon(AssetImage(AllAssets.bottomPT),
                          color: context.read<AuthState>().currentIndex == 4
                              ? Color(0xFFAAAAAA)
                              : Color.fromARGB(132, 170, 170, 170)),
                      onPressed: () {
                        context.read<AuthState>().changeIndex(4);
                        Navigator.pushReplacement(
                            context, MaterialPageRoute(builder: (context) => BottomNavigation()));
                      }),
                ],
              ),
            )
          ],
        ),
        floatingActionButton: _isLoading ? SizedBox() : buildBoomMenu());
  }

  buildBoomMenu() {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: getWidgetHeight(height: 80)),
      child: BoomMenu(
          animatedIcon: AnimatedIcons.menu_close,
          animatedIconTheme: IconThemeData(size: 22.0, color: AppColors.white),
          onOpen: () {
            print('OPENING DIAL');
          },
          onClose: () {
            print('DIAL CLOSED');
          },
          backgroundColor: Color(0xFF6C63FE),
          overlayColor: Color(0Xff293750), //Colors.transparent,
          overlayOpacity: 0.6,
          children: [
            bm.MenuItem(
              child: Container(
                padding: EdgeInsets.symmetric(
                    horizontal: getWidgetWidth(width: 12),
                    vertical: isSplitScreen ? getFullWidgetHeight(height: 12) : getWidgetHeight(height: 12)),
                decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                child: Icon(
                  Icons.home,
                  color: Colors.grey,
                  size: isSplitScreen ? getFullWidgetHeight(height: 18) : getWidgetHeight(height: 18),
                ),
              ),
              title: "Home",
              titleColor: Colors.white,
              backgroundColor: Color(0x00000000),
              onTap: () {
                context.read<AuthState>().changeIndex(0);
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => BottomNavigation()));
              },
            ),
            bm.MenuItem(
              child: Container(
                padding: EdgeInsets.symmetric(
                    horizontal: getWidgetWidth(width: 12),
                    vertical: isSplitScreen ? getFullWidgetHeight(height: 12) : getWidgetHeight(height: 12)),
                decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                child: Icon(
                  Icons.keyboard,
                  color: Colors.grey,
                  size: isSplitScreen ? getFullWidgetHeight(height: 18) : getWidgetHeight(height: 18),
                ),
              ),
              title: "Try Unlisted Words",
              titleColor: Colors.white,
              backgroundColor: Colors.transparent,
              onTap: () {
                isAllPlaying = false;
                isAllPlaying = false;

                setState(() {});
                showDialog(
                  useRootNavigator: true,
                  context: context,
                  builder: (BuildContext context) {
                    return OwnWordDialog(
                      isFromWord: true,
                    );
                    // return OwnWordResultDialog();
                  },
                );
              },
            ),
            bm.MenuItem(
              child: Container(
                  padding: EdgeInsets.symmetric(
                      horizontal: getWidgetWidth(width: 12),
                      vertical: isSplitScreen ? getFullWidgetHeight(height: 12) : getWidgetHeight(height: 12)),
                  decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                  child: Image.asset("assets/images/filter.png",
                      color: Colors
                          .grey) /*
          child: Icon(
            Icons.check_box,
            color: Colors.grey,
            size: 18,
          ),*/
              ),
              title: "Filter Priority",
              titleColor: Colors.white,
              backgroundColor: Colors.transparent,
              onTap: () {
                isAllPlaying = false;
                isAllPlaying3 = false;

                setState(() {});
                log("dohdougdugdugdu : ${repeatLoads}");
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => WordScreen(
                          title: "Priority List",
                          load: "",
                          filterLoad: repeatLoads,
                        ))).then((val) => _getWords(isRefresh: false));
              },
            ),
            bm.MenuItem(
              child: Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                  child: Image.asset("assets/images/filter_all.png", color: Colors.grey)),
              title: "Filter All Priority",
              titleColor: Colors.white,
              backgroundColor: Colors.transparent,
              onTap: () {
                isAllPlaying = false;
                isAllPlaying3 = false;

                setState(() {});
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => WordScreen(
                          title: "All Priority List",
                          load: "",
                        ))).then((val) => _getWords(isRefresh: false));
              },
            ),
          ]),
    );
  }
}