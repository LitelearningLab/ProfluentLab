import 'dart:async';

import 'package:after_layout/after_layout.dart';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:litelearninglab/utils/sizes_helpers.dart';
import 'package:video_player/video_player.dart';

import '../../common_widgets/background_widget.dart';

class VideoPlayerScreen extends StatefulWidget {
  VideoPlayerScreen({Key? key, required this.url}) : super(key: key);
  final String url;

  @override
  _VideoPlayerScreenState createState() {
    return _VideoPlayerScreenState();
  }
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen>
    with AfterLayoutMixin<VideoPlayerScreen> {
  late VideoPlayerController _controller;
  late ChewieController _chewieController;
  late Future<void> _initializeVideoPlayerFuture;
  bool _isBackShow = false;
  bool _isPlaying = true;
  double _currentSliderValue = 0.0;

  @override
  void initState() {
    super.initState();

    _controller = VideoPlayerController.network(widget.url);
    _chewieController = ChewieController(
      videoPlayerController: _controller,
      autoInitialize: true,
      autoPlay: false,
      showOptions: false,
      showControls: true,
      allowFullScreen: false,
      fullScreenByDefault: true
    );
    _initializeVideoPlayerFuture = _controller.initialize();
    _controller.addListener(() {
      setState(() {
        _currentSliderValue = _controller.value.position.inSeconds.toDouble();
        _isPlaying = _controller.value.isPlaying;
      });
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _chewieController.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    super.dispose();
  }

  void _onSliderValueChanged(double value) {
    setState(() {
      _currentSliderValue = value;
      _controller.seekTo(Duration(seconds: value.toInt()));
    });
  }

  @override
  FutureOr<void> afterFirstLayout(BuildContext context) {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    SystemChrome.setPreferredOrientations(
        [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    _controller.play();
  }

  String formatDuration(Duration duration) {
    var remaining = duration - _controller.value.position;
    String minutes =
        remaining.inMinutes.remainder(60).toString().padLeft(2, '0');
    String seconds =
        remaining.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    return BackgroundWidget(
      body: FutureBuilder(
        future: _initializeVideoPlayerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Stack(
              children: [
                InkWell(
                  onTap: () {
                    _isBackShow = !_isBackShow;
                    setState(() {});
                  },
                  child: SizedBox(
                    width: displayWidth(context),
                    height: displayHeight(context),
                    child: Chewie(controller: _chewieController)
                  ),
                ),
                Positioned(
                    top: 20,
                    left: 20,
                    child: Container(
                      decoration: BoxDecoration(
                          shape: BoxShape.circle, color: Colors.white),
                      child: IconButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          icon: Icon(Icons.arrow_back)),
                    )),
              ],
            );
          } else {
            return Center(child: CircularProgressIndicator());
          }
        },
      ),
    );
  }
}
