import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:litelearninglab/constants/all_assets.dart';
import 'package:litelearninglab/constants/keys.dart';
import 'package:scroll_to_index/scroll_to_index.dart';
import 'package:video_player/video_player.dart';

import '../../common_widgets/background_widget.dart';
import '../../common_widgets/common_app_bar.dart';
import '../../common_widgets/spacings.dart';
import '../../constants/app_colors.dart';
import '../../models/ProfluentSubLink.dart';
import '../../models/Word.dart';
import '../../utils/sizes_helpers.dart';
import '../dialogs/speech_analytics_dialog.dart';

class ProfluentSubScreen extends StatefulWidget {
  ProfluentSubScreen({Key? key, required this.links, required this.load, required this.title}) : super(key: key);
  final ProfluentSubLink links;
  final String load;
  final String title;

  @override
  _ProfluentSubScreenState createState() {
    return _ProfluentSubScreenState();
  }
}

class _ProfluentSubScreenState extends State<ProfluentSubScreen> {
  int _selected = 0;
  late VideoPlayerController _controller;
  late Future<VideoPlayerController> _initializeVideoPlayerFuture;
  bool _isPlaying = true;
  late AutoScrollController controller;
  late ChewieController _chewieController;
  bool _isCorrect = false;
  String _selectedWord = "";
  List<Word> _words = [];

  @override
  void initState() {
    super.initState();
    _initializeVideoPlayerFuture = _initVideoPlayer(url: widget.links.v1!);
  }

  Future<VideoPlayerController> _initVideoPlayer({required String url}) async {
    _controller = VideoPlayerController.networkUrl(Uri.parse(url));
    _initializeChewieController();
    return _controller;
  }

  _initializeChewieController() {
    _chewieController = ChewieController(
        videoPlayerController: _controller, autoInitialize: true, autoPlay: false, showOptions: false, showControls: true, allowFullScreen: false, fullScreenByDefault: false);
  }

  String formatDuration(Duration duration) {
    var remaining = duration - _controller.value.position;
    String minutes = remaining.inMinutes.remainder(60).toString().padLeft(2, '0');
    String seconds = remaining.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  void dispose() {
    _controller.dispose();
    _chewieController.dispose();
    super.dispose();
  }

  void _onClick(int index) {
    print("index : $index");
    print("_selected : $_selected");
    if (_selected != index) {
      late String url;
      if (index == 0) {
        url = widget.links.v1!;
      } else if (index == 1) {
        url = widget.links.v2!;
      } else if (index == 2) {
        url = widget.links.v3!;
      } else if (index == 3) {
        url = widget.links.v4!;
      } else if (index == 4) {
        url = widget.links.v5!;
      } else if (index == 5) {
        print("its here coidfofihpifhipjas");
        _showDialog('monday tuesday', false, context);
      }
      if (index != 5) {
        _controller.pause();
        _controller = VideoPlayerController.networkUrl(Uri.parse(url));
        _controller.initialize().then((_) {
          _chewieController.dispose();
          _initializeChewieController();
          setState(() {});
        });
      }
      _selected = index;
    }
  }

  void _showDialog(String word, bool notCatch, BuildContext context) async {
    print("hello hii");
    Get.dialog(
      Container(
        child: Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25.0)),
          child: SpeechAnalyticsDialog(
            true,
            isShowDidNotCatch: notCatch,
            word: word,
            title: widget.title,
            load: widget.load,
          ),
        ),
      ),
    ).then((value) {
      if (value != null && value.isCorrect == "true" || value.isCorrect == "false") {
        print("first test cases");
        _selectedWord = word;
        _isCorrect = value.isCorrect == "true" ? true : false;
        print("is pronun correct : $_isCorrect");
        setState(() {});
        _WordAnalysisResult(context);
      } else if (value != null && value.isCorrect == "notCatch") {
        print("two test cases");
        _showDialog(word, true, context);
      } else if (value != null && value.isCorrect == "openDialog") {
        print("third test cases");
        _showDialog(word, false, context);
      }
    });
  }

  void _WordAnalysisResult(BuildContext context) async {
    print("hello hii");
    Get.dialog(
      Container(
        child: Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25.0)),
          child: ListTile(
            title: Text(
              "Pronunciation Analysis Result",
              style: TextStyle(color: AppColors.green, fontSize: 13, fontFamily: Keys.fontFamily),
            ),
            subtitle: Text(
              "Note: This result only indicates intelligibility and does not confirm the accuracy of pronunciation.",
              style: TextStyle(color: AppColors.white, fontSize: 10, fontFamily: Keys.fontFamily),
            ),
            trailing: Icon(
              _isCorrect ? Icons.check_circle : Icons.cancel,
              color: _isCorrect ? AppColors.green : Colors.red,
              size: 45,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BackgroundWidget(
      appBar: CommonAppBar(
        title: widget.load,
        fontFamily: Keys.lucidaFontFamily,
      ),
      body: FutureBuilder(
        future: _initializeVideoPlayerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Column(
              children: [
                SPH(displayHeight(context) * 0.01),
                SizedBox(width: displayWidth(context), height: displayWidth(context), child: Chewie(controller: _chewieController)),
                SPH(15),
                GridView.builder(
                  shrinkWrap: true,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, // Number of columns in the grid
                    mainAxisSpacing: 2, // Spacing between rows
                    crossAxisSpacing: 2, // Spacing between columns
                    childAspectRatio: 4, // Width to height ratio of each grid item
                  ),
                  itemCount: 6, // Total number of items in the grid
                  itemBuilder: (BuildContext context, int index) {
                    return InkWell(
                      onTap: () {
                        _onClick(index);
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 2, vertical: 5),
                        decoration: BoxDecoration(
                          color: Color(0xff333a40),
                        ),
                        child: Row(
                          children: [
                            if (index != 5)
                              Image.asset(
                                "assets/images/pl${index + 1}.png",
                                width: 35,
                              ),
                            if (index == 5) SPW(5),
                            if (index == 5)
                              Icon(
                                Icons.mic,
                                color: Colors.white,
                              ),
                            if (index == 5) SPW(8),
                            SPW(10),
                            Text(
                              index == 0
                                  ? "Front View"
                                  : index == 1
                                      ? "Side View"
                                      : index == 2
                                          ? "Front Closer"
                                          : index == 3
                                              ? "Side Closer"
                                              : index == 4
                                                  ? "Animation"
                                                  : "Practice Lab",
                              style: TextStyle(
                                  color: (((widget.links.v1 == null || widget.links.v1!.isEmpty) && index == 0) ||
                                          ((widget.links.v2 == null || widget.links.v2!.isEmpty) && index == 1) ||
                                          ((widget.links.v3 == null || widget.links.v3!.isEmpty) && index == 2) ||
                                          ((widget.links.v4 == null || widget.links.v4!.isEmpty) && index == 3) ||
                                          ((widget.links.v5 == null || widget.links.v5!.isEmpty) && index == 4) ||
                                          ((widget.links.words == null || widget.links.words!.isEmpty) && index == 5))
                                      ? Colors.grey
                                      : Colors.white,
                                  fontSize: 15),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ],
            );
          } else {
            return Center(child: CircularProgressIndicator());
          }
        },
      ),
    );
  }
}
