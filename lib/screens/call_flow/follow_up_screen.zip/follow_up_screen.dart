import 'dart:async';
import 'dart:developer';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:litelearninglab/common_widgets/spacings.dart';
import 'package:litelearninglab/constants/all_assets.dart';
import 'package:litelearninglab/constants/app_colors.dart';
import 'package:litelearninglab/constants/keys.dart';
import 'package:litelearninglab/models/Sentence.dart';
import 'package:litelearninglab/screens/dialogs/sentence_result_dialog.dart';
import 'package:litelearninglab/screens/dialogs/speech_analytics_dialog.dart';
import 'package:litelearninglab/states/auth_state.dart';
import 'package:litelearninglab/utils/firebase_helper.dart';
import 'package:litelearninglab/utils/firebase_helper_RTD.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../../common_widgets/background_widget.dart';
import '../../database/SentDatabaseProvider.dart';
import '../../database/SentencesDatabaseRepository.dart';
import '../../utils/audio_player_manager.dart';
import '../../utils/encrypt_data.dart';
import '../../utils/utils.dart';

enum PlayingRouteState { speakers, earpiece }

class FollowUpScreen extends StatefulWidget {
  FollowUpScreen(
      {Key? key,
      required this.title,
      required this.load,
      required this.user,
      required this.main})
      : super(key: key);
  final AuthState user;
  final String title;
  final String main;
  final String load;

  @override
  _FollowUpScreenState createState() {
    return _FollowUpScreenState();
  }
}

class _FollowUpScreenState extends State<FollowUpScreen> {
  FirebaseHelperRTD db = new FirebaseHelperRTD();
  List<Sentence> _followUps = [];

  StreamSubscription? _playerStateSubscription;

  bool _isLoading = false;
  bool _isAllDownloaded = false;
  bool _isDownloading = false;
  final _audioPlayerManager = AudioPlayerManager();
  bool _isPlaying = false;
  int _currentPlayingIndex = -1;
  @override
  void initState() {
    super.initState();
    _playerStateSubscription =
        _audioPlayerManager.onPlayerStateChanged.listen((event) {
      if (event == PlayerState.playing) {
        _isPlaying = true;
      } else {
        _isPlaying = false;
      }
      setState(() {});
    });
    _getFollowUps();
  }

  @override
  void dispose() {
    _audioPlayerManager.dispose();

    _playerStateSubscription?.cancel();
    super.dispose();
  }

  Future<void> _play(String url, String sentence, int index,
      {String? localPath}) async {
    String? eLocalPath;
   await _audioPlayerManager.stop();

    await _audioPlayerManager.play(url, localPath: localPath, context: context,
        decodedPath: (val) {
      eLocalPath = val;
    });
  

    FirebaseHelper db = new FirebaseHelper();
    AuthState userDatas = Provider.of<AuthState>(context, listen: false);
    db.saveCallFlowReport(
      isPractice: false,
      company: userDatas.appUser!.company!,
      name: userDatas.appUser!.UserMname,
      userID: userDatas.appUser!.id!,
      sentence: sentence,
      team: userDatas.appUser?.team,
      userprofile: userDatas.appUser?.profile,
      city: userDatas.appUser?.city,
      date: DateFormat('dd-MMM-yyyy').format(DateTime.now()),
    );
    
    _currentPlayingIndex = index;
    

    if (eLocalPath != null && eLocalPath!.isNotEmpty) {
      try {
        await File(eLocalPath!).delete();
      } catch (e) {}
    }
  }

  void _getFollowUps() async {
    print('/////////CALLING FOLLOWUP//////////');
    setState(() {
      _isLoading = true;
    });
    _followUps =
        await db.getFollowUps("Call Flow Practice", widget.main, widget.load);
    _followUps.forEach((element) {
      print("////////DATAS : : : ${element.toJson()}");
    });
    print("Main : : : ${widget.main}");
    print("Load : : : ${widget.load}");

    _isAllDownloaded = true;
    for (Sentence sent in _followUps) {
      if (sent.localPath == null) {
        _isAllDownloaded = false;
      }
    }

    _isLoading = false;
    setState(() {});
  }

  void _showDialog(String word, bool notCatch, BuildContext context) async {
    Get.dialog(Container(
      // color: Color(0xCC000000),
      child: Dialog(
        // backgroundColor: AppColors.black,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(25.0)),
        //this right here
        child: SpeechAnalyticsDialog(
          false,
          isShowDidNotCatch: notCatch,
          word: word,
          title: widget.title,
          isCallflow: true,
          load: widget.load,
        ),
      ),
    )).then((value) {
      if (value != null && value.isCorrect == "true" ||
          value.isCorrect == "false") {
        showDialog(
          context: context,
          builder: (BuildContext buildContext) {
            return Dialog(
              // backgroundColor: AppColors.c262626,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25.0)),
              //this right here
              child: SentenceResultDialog(
                correctedWidget: value.formatedWords,
                score: value.wordPer,
                word: word,
                isCorrect: value.isCorrect == "true" ? true : false,
              ),
            );
          },
        );
      } else if (value != null && value.isCorrect == "notCatch") {
        _showDialog(word, true, context);
      } else if (value != null && value.isCorrect == "openDialog") {
        _showDialog(word, false, context);
      }
    });
  }

  Future<void> downloadAll() async {
    setState(() {
      _isDownloading = true;
    });
    for (Sentence sentence in _followUps) {
      SentDatabaseProvider dbb = SentDatabaseProvider.get;
      SentencesDatabaseRepository dbRef = SentencesDatabaseRepository(dbb);

      Directory appDocDir = await getApplicationDocumentsDirectory();
      String appDocPath = appDocDir.path;
      String localPath = await Utils.downloadFile(
          sentence.file!, '${sentence.id}.mp3', '$appDocPath/${widget.load}');
      print(localPath);

      String eLocalPath = EncryptData.encryptFile(localPath, context);
      print(eLocalPath);
      try {
        await File(localPath).delete();
      } catch (e) {}

      await dbRef.setDownloadPath(sentence.id!, eLocalPath);
    }
    setState(() {
      _isDownloading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return BackgroundWidget(
      appBar: AppBar(
        centerTitle: false,
        title: Text(
          widget.main,
          style: TextStyle(
              fontFamily: Keys.fontFamily,
              fontSize: 17,
              color: Colors.white,
              fontWeight: FontWeight.w500),
        ),
        backgroundColor: Color(0xff333a40),
        iconTheme: IconThemeData(color: Colors.white),
        actions: [
          if (!_isAllDownloaded && !_isDownloading)
            InkWell(
              onTap: downloadAll,
              child: Icon(
                Icons.file_download,
                color: AppColors.white,
              ),
            ),
          if (_isAllDownloaded)
            InkWell(
              onTap: () {},
              child: Icon(
                Icons.file_download_done,
                color: AppColors.white,
              ),
            ),
          if (_isDownloading && !_isAllDownloaded)
            SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: Colors.white,
                )),
          SPW(20)
        ],
      ),
      body: _isLoading?Center(child: CircularProgressIndicator(),): Stack(
        children: [
          ListView(
            children: [
              // SPH(10),
              Container(
                alignment: Alignment.center,
                margin: EdgeInsets.symmetric(horizontal: 10),
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 7),
                // decoration: new BoxDecoration(
                //   borderRadius: new BorderRadius.circular(10.0),
                //   color: AppColors.chatBack,
                // ),
                child: Text(
                  widget.load,
                  style: TextStyle(
                      color: AppColors.white,
                      fontFamily: Keys.fontFamily,
                      fontWeight: FontWeight.w500,
                      fontStyle: FontStyle.italic,
                      fontSize: 20),
                ),
              ),
              // SPH(10),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 7),
                child: ListView.builder(
                    itemCount: _followUps.length,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (BuildContext context, int index) {
                      if (index % 2 == 0) {
                        return Card(
                          color: Color(0xff202328),
                          child: Row(
                            children: [
                              Flexible(
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 10),
                                  decoration: new BoxDecoration(
                                    borderRadius:
                                        new BorderRadius.circular(10.0),
                                    // color: AppColors.chatRight,
                                    color: Color(0xff333a40),
                                  ),
                                  child: Column(
                                    children: [
                                      Text(
                                        _followUps[index].text ?? "",
                                        style: TextStyle(
                                            color: AppColors.white,
                                            fontFamily: Keys.fontFamily,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 15),
                                      ),
                                      SPH(5),
                                      Row(
                                        children: [
                                          // if (!_isPlaying)
                                          InkWell(
                                            onTap: () {
                                              if (_isPlaying &&
                                                  _currentPlayingIndex ==
                                                      index) {
                                                _audioPlayerManager.stop();
                                              } else {
                                                _play(
                                                    _followUps[index].file!,
                                                    _followUps[index].text!,
                                                    index,
                                                    localPath: _followUps[index]
                                                        .localPath);
                                              }
                                              //  !_isPlaying? _play(
                                              //       _followUps[index].file!,
                                              //       _followUps[index].text!,
                                              //       index,
                                              //       localPath: _followUps[index]
                                              //           .localPath):_audioPlayerManager.stop();
                                              //   print("CALL FLOW LOCALPATH : : : ${_followUps[index].localPath}");
                                            },
                                            child:Icon(  _isPlaying &&
                                                      _currentPlayingIndex ==
                                                          index
                                                  ? Icons.pause_circle_outline
                                                  
                                                  : Icons.play_circle_outline,
                                              color: Color(0xff71b800),
                                              size: 30,
                                            ),
                                          ),
                                          // if (_isPlaying)
                                          //   InkWell(
                                          //       onTap: () {
                                          //         _audioPlayerManager.stop();
                                          //       },
                                          //       child: Icon(
                                          //         Icons.pause_circle_outline,
                                          //         color: Color(0xff71b800),
                                          //         size: 30,
                                          //       )),
                                          SPW(35),
                                          InkWell(
                                            onTap: () {
                                              _showDialog(
                                                  _followUps[index].text!,
                                                  false,
                                                  context);
                                            },
                                            child: Icon(
                                              Icons.mic,
                                              size: 30,
                                              color: Color(0xff71b800),
                                            ),
                                          ),
                                          // SPW(15),
                                          // Image.asset(
                                          //   AllAssets.dfb,
                                          //   width: 30,
                                          //   color: Colors.white,
                                          // ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              SPW(10),
                              Image.asset(
                                AllAssets.winstonNew,
                                width: 40,
                              ),
                            ],
                          ),
                        );
                      } else {
                        return Card(
                          color: Color(0xff202328),
                          child: Row(
                            children: [
                              Image.asset(
                                AllAssets.lindaNew,
                                width: 40,
                              ),
                              SPW(10),
                              Flexible(
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 15, vertical: 10),
                                  decoration: new BoxDecoration(
                                    borderRadius:
                                        new BorderRadius.circular(10.0),
                                    color: AppColors.chatLeft,
                                  ),
                                  child: Column(
                                    children: [
                                      Text(
                                        _followUps[index].text ?? "",
                                        style: TextStyle(
                                            color: AppColors.black,
                                            fontFamily: Keys.fontFamily,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 15),
                                      ),
                                      SPH(5),
                                      Row(
                                        children: [
                                          // if (!_isPlaying)
                                          InkWell(
                                            onTap: () {
                                              if (_isPlaying &&
                                                  _currentPlayingIndex ==
                                                      index) {
                                                _audioPlayerManager.stop();
                                              } else {
                                                _play(
                                                    _followUps[index].file!,
                                                    _followUps[index].text!,
                                                    index,
                                                    localPath: _followUps[index]
                                                        .localPath);
                                              }
                                            },
                                            child: Icon(
                                              _isPlaying &&
                                                      _currentPlayingIndex ==
                                                          index
                                                  ? Icons.pause_circle_outline
                                                  : Icons.play_circle_outline,
                                              color: Color(0xff0588e2),
                                              size: 30,
                                            ),
                                          ),
                                          // if (_isPlaying)
                                          //   InkWell(
                                          //       onTap: () {
                                          //         _audioPlayerManager.stop();
                                          //       },
                                          //       child: Icon(
                                          //         Icons.pause_circle_outline,
                                          //         color: Color(0xff0588e2),
                                          //         size: 30,
                                          //       )),
                                          SPW(35),
                                          InkWell(
                                            child: Icon(
                                              Icons.mic,
                                              size: 30,
                                              color: Color(0xff0588e2),
                                            ),
                                            onTap: () {
                                              _showDialog(
                                                  _followUps[index].text!,
                                                  false,
                                                  context);
                                            },
                                          ),
                                          // SPW(15),
                                          // Image.asset(
                                          //   AllAssets.dfb,
                                          //   color: Color(0xff0b298f),
                                          //   width: 30,
                                          // ),
                                        ],
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            ],
                          ),
                        );
                      }
                    }),
              ),
            ],
          ),
          if (_isLoading) Center(child: CircularProgressIndicator())
        ],
      ),
    );
  }
}
