import 'package:flutter/material.dart';
import 'package:litelearninglab/common_widgets/common_app_bar.dart';
import 'package:litelearninglab/common_widgets/spacings.dart';
import 'package:litelearninglab/constants/app_colors.dart';
import 'package:litelearninglab/constants/keys.dart';
import 'package:litelearninglab/models/SentenceCat.dart';
import 'package:litelearninglab/states/auth_state.dart';
import 'package:litelearninglab/utils/firebase_helper_RTD.dart';

import '../../common_widgets/background_widget.dart';
import 'follow_up_screen.dart';

class CallFlowCatScreen extends StatefulWidget {
  CallFlowCatScreen(
      {Key? key, required this.title, required this.user, required this.load})
      : super(key: key);
  final AuthState user;
  final String title;
  final String load;
  @override
  _CallFlowCatScreenState createState() {
    return _CallFlowCatScreenState();
  }
}

class _CallFlowCatScreenState extends State<CallFlowCatScreen> {
  FirebaseHelperRTD db = new FirebaseHelperRTD();
  List<SentenceCat> _sentCat = [];
  bool _isLoading = false;
  @override
  void initState() {
    super.initState();
    _getSentCat();
  }

  void _getSentCat() async {
    setState(() {
      _isLoading = true;
    });
    _sentCat = await db.getSentencesCat(widget.load, "Call Flow Practice");
    _isLoading = false;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return BackgroundWidget(
      appBar: CommonAppBar(
        title: widget.title,
      ),
      body: Stack(
        children: [
          ListView.builder(
              itemCount: _sentCat.length,
              itemBuilder: (BuildContext context, int index) {
                return InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => FollowUpScreen(
                                  user: widget.user,
                                  title: _sentCat[index].title ?? "",
                                  load: _sentCat[index].title ?? "",
                                  main: widget.load,
                                )));
                  },
                  child: Card(
                    margin: EdgeInsets.symmetric(vertical: 1),
                    color: Color(0xff333a40),
                    child: Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 10, vertical: 20),
                      child: Row(
                        children: [
                          Icon(
                            Icons.format_list_bulleted,
                            color: AppColors.white,
                          ),
                          SPW(10),
                          Flexible(
                            child: Text(
                              _sentCat[index].title ?? "",
                              style: TextStyle(
                                  color: AppColors.white,
                                  fontFamily: Keys.fontFamily,
                                  fontSize: 17),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
          if (_isLoading) Center(child: CircularProgressIndicator())
        ],
      ),
    );
  }
}
