import 'dart:convert';
import 'dart:developer';

import 'package:firebase_database/firebase_database.dart';
import 'package:litelearninglab/database/SentDatabaseProvider.dart';
import 'package:litelearninglab/database/SentencesDatabaseRepository.dart';
import 'package:litelearninglab/database/WordsDatabaseRepository.dart';
import 'package:litelearninglab/database/databaseProvider.dart';
import 'package:litelearninglab/models/Sentence.dart';
import 'package:litelearninglab/models/SentenceCat.dart';
import 'package:litelearninglab/models/Word.dart';
import 'package:litelearninglab/utils/shared_pref.dart';

class FirebaseHelperRTD {
  static final FirebaseHelperRTD _instance = new FirebaseHelperRTD.internal();

  factory FirebaseHelperRTD() => _instance;
  final FirebaseDatabase _database = FirebaseDatabase.instance;

  FirebaseHelperRTD.internal();

  Future<List<Word>> searchWord(String searchTerm) async {
    List<Word> words = [];
    print("searchTerm : $searchTerm");
    List<Word> daysdates = await getWords("daysdates");
    // words.addAll(daysdates.where((element) => element.text?.toLowerCase() == searchTerm.toLowerCase()).toList());
    words.addAll(daysdates.where((element) => element.text!.toLowerCase().startsWith(searchTerm.toLowerCase())).toList());
    print("words : $words");
    log("before>>>>>>>>>>>>>>>>");
    log("${words.length}");

    // if (words.length > 0) return words;

    List<Word> LattersandNATO = await getWords("Latters and NATO");
    words.addAll(LattersandNATO.where((element) => element.text!.toLowerCase().startsWith(searchTerm.toLowerCase())).toList());
    log("after>>>>>>>>>>>>>>>>");
    log("${words.length}");

    List<Word> StatesandCities = await getWords("States and Cities");
    words.addAll(StatesandCities.where((element) => element.text!.toLowerCase().startsWith(searchTerm.toLowerCase())).toList());
    // words.addAll(StatesandCities.where((element) =>
    //     element.text?.toLowerCase() == searchTerm.toLowerCase()).toList());
    // if (words.length > 0) return words;

    List<Word> CommonWords = await getWords("CommonWords");
    words.addAll(CommonWords.where((element) => element.text!.toLowerCase().startsWith(searchTerm.toLowerCase())).toList());
    // words.addAll(CommonWords.where((element) =>
    //     element.text?.toLowerCase() == searchTerm.toLowerCase()).toList());
    // if (words.length > 0) return words;

    List<Word> USHealthcare = await getWords("US Healthcare");
    words.addAll(USHealthcare.where((element) => element.text!.toLowerCase().startsWith(searchTerm.toLowerCase())).toList());
    // words.addAll(USHealthcare.where((element) =>
    //     element.text?.toLowerCase() == searchTerm.toLowerCase()).toList());
    // if (words.length > 0) return words;

    List<Word> TravelTourism = await getWords("Travel Tourism");
    words.addAll(TravelTourism.where((element) => element.text!.toLowerCase().startsWith(searchTerm.toLowerCase())).toList());
    // words.addAll(TravelTourism.where((element) =>
    //     element.text?.toLowerCase() == searchTerm.toLowerCase()).toList());
    // if (words.length > 0) return words;

    List<Word> InformationTechnology = await getWords("Information Technology");
    words.addAll(InformationTechnology.where((element) => element.text!.toLowerCase().startsWith(searchTerm.toLowerCase())).toList());
    // words.addAll(InformationTechnology.where((element) =>
    //     element.text?.toLowerCase() == searchTerm.toLowerCase()).toList());
    // if (words.length > 0) return words;

    List<Word> BusinessWords = await getWords("Business Words");
    words.addAll(BusinessWords.where((element) => element.text!.toLowerCase().startsWith(searchTerm.toLowerCase())).toList());
    // words.addAll(BusinessWords.where((element) =>
    //     element.text?.toLowerCase() == searchTerm.toLowerCase()).toList());
    // if (words.length > 0) return words;

    List<Word> ProcessWords = await getWords("ProcessWords");
    words.addAll(ProcessWords.where((element) => element.text!.toLowerCase().startsWith(searchTerm.toLowerCase())).toList());
    // words.addAll(ProcessWords.where((element) =>
    //     element.text?.toLowerCase() == searchTerm.toLowerCase()).toList());
    if (words.length > 0) return words;

    return words;
  }

  Future<List<Word>> lettersAndNatp(String searchTerm) async {
    List<Word> lettersAndNatp = [];
    List<Word> LattersandNATO = await getWords("Latters and NATO");
    log("${LattersandNATO.length}");
    for (Word i in LattersandNATO) {
      log("${i.text}");
    }
    log("lettersAndnatp only length has been printed");
    lettersAndNatp.addAll(LattersandNATO.where((element) => element.text!.toUpperCase().contains(searchTerm.toUpperCase())).toList());

    log("${lettersAndNatp.length}");
    log("lettersAnd natp length has been printed");
    if (lettersAndNatp.length > 0) return lettersAndNatp;

    return lettersAndNatp;
  }

  Future<List<Word>> getWords(String load) async {
    print("load");
    print(load);

    List<Word> words = [];
    DatabaseProvider dbb = DatabaseProvider.get;
    WordsDatabaseRepository dbRef = WordsDatabaseRepository(dbb);

    bool isSaved = await SharedPref.getSavedBool(load);
    // bool isSaved = false;
    if (isSaved) {
      List<Word> wordsList = await dbRef.getWords();
      words = wordsList.where((element) => element.cat == load).toList();
    } else {
      await _database.ref(load).orderByValue().once().then((DatabaseEvent snap) async {
        var keys = snap.snapshot.children;
        // var data = snap.snapshot.value;
        words.clear();

        for (DataSnapshot key in keys) {
          // print(key.value);
          var data = json.decode(json.encode(key.value));
          print(data);
          Word d = new Word();
          d.file = data['file'] ?? "";
          d.pronun = data['pronun'] ?? "";

          d.syllables = data['syllables'] != null ? data['syllables'].toString() : "";
          d.text = data['text'].toString();
          d.cat = load;
          d.isFav = 0;

          dbRef.insert(d);
          words.add(d);
        }

        if (keys.length > 0) {
          List<Word> wordsList = await dbRef.getWords();
          words = wordsList.where((element) => element.cat == load).toList();
          SharedPref.saveBool(load, true);
        }
      });
      //     .then((DatabaseEvent snap) async {
      //   var keys = snap.value.keys;
      //   var data = snap.value;
      //   words.clear();
      //
      //   for (var key in keys) {
      //     Word d = new Word();
      //     d.file = data[key]['file'];
      //     d.pronun = data[key]['pronun'];
      //     d.syllables = data[key]['syllables'] != null
      //         ? data[key]['syllables'].toString()
      //         : "";
      //     d.text = data[key]['text'].toString();
      //     d.cat = load;
      //     d.isFav = 0;
      //
      //     dbRef.insert(d);
      //     // words.add(d);
      //   }
      //
      //   if (keys.length > 0) {
      //     List<Word> wordsList = await dbRef.getWords();
      //     words = wordsList.where((element) => element.cat == load).toList();
      //     SharedPref.saveBool(load, true);
      //   }
      // });
    }

    return words;
  }

  // Future<List<ProcessLearningMain>> getProcessLearning() async {
  //   List<ProcessLearningMain> words = [];
  //   print("getProcessLearning");
  //   await _database
  //       .ref("procrssLearning")
  //       .orderByValue()
  //       .once()
  //       .then((DatabaseEvent snap) async {
  //     var keys = snap.snapshot.children;
  //     // var data = snap.value;
  //     words.clear();
  //
  //     for (DataSnapshot key in keys) {
  //       Map data = json.decode(json.encode(key.value));
  //       print(data['categories']);
  //       Map? map = data['categories'];
  //       List<ProcessLeaningCat> cats = [];
  //       if (map != null) print(map.length);
  //       ProcessLearningMain d = new ProcessLearningMain();
  //       d.catname = data['catname'] ?? "";
  //       if (map != null)
  //         map.entries.forEach((e) => cats.add(ProcessLeaningCat(
  //             e.key, e.value["image"], e.value["text"], e.value["url"])));
  //       d.categories = cats;
  //
  //       words.add(d);
  //     }
  //   });
  //
  //   return words;
  // }

  Future<List<SentenceCat>> getSentencesCat(String load, String main) async {
    print(load);

    List<SentenceCat> sentenceCats = [];

    await _database.ref().child(main).child(load).once().then((DatabaseEvent snap) {
      var keys = snap.snapshot.children;
      // var data = snap.value;
      sentenceCats.clear();

      for (var key in keys) {
        SentenceCat d = new SentenceCat();
        d.title = key.key;

        sentenceCats.add(d);
      }
    });

    return sentenceCats;
  }

  Future<List<Sentence>> getFollowUps(String main, String sub, String load) async {
    print(load);

    List<Sentence> followUps = [];
    SentDatabaseProvider dbb = SentDatabaseProvider.get;
    SentencesDatabaseRepository dbRef = SentencesDatabaseRepository(dbb);

    bool isSaved = await SharedPref.getSavedBool(main);
    if (isSaved) {
      print("Is Saved : ${isSaved}");
      List<Sentence> wordsList = await dbRef.getWords();
      final category = wordsList[0].cat;
      if (category == load) {
        print('Get WOrds : : : ${wordsList}');
      followUps = wordsList;
      // .where((element) => element.cat == load).toList();
      wordsList.forEach((element) { 
        log("WORDLIST : : : ${element.toJson()}");
      });
      print("FOLLOWUP : : :${followUps}");
      }else{
        dbRef.clearAllData();

        await _database
          .ref()
          .child(main)
          .child(sub)
          .child(load)
          //.orderByKey()
          .once()
          .then((DatabaseEvent snap) async {
        var keys = snap.snapshot.children;
        // var data = snap.value;
        followUps.clear();

        for (var key in keys) {
          var data = json.decode(json.encode(key.value));
          Sentence d = new Sentence();
          d.file = data['file'] ?? "";
          d.text = data['text'] ?? "";
          d.cat = load;
          d.isFav = 0;

          dbRef.insert(d);
          // followUps.add(d);
        }

        if (keys.length > 0) {
          List<Sentence> wordsList = await dbRef.getWords();
          followUps = wordsList.where((element) => element.cat == load).toList();
          SharedPref.saveBool(main, true);
        }
      });
      }
      // print('Get WOrds : : : ${wordsList}');
      // followUps = wordsList;
      // // .where((element) => element.cat == load).toList();
      // wordsList.forEach((element) { 
      //   log("WORDLIST : : : ${element.toJson()}");
      // });
      // print("FOLLOWUP : : :${followUps}");
    } else {
      await _database
          .ref()
          .child(main)
          .child(sub)
          .child(load)
          //.orderByKey()
          .once()
          .then((DatabaseEvent snap) async {
        var keys = snap.snapshot.children;
        // var data = snap.value;
        followUps.clear();

        for (var key in keys) {
          var data = json.decode(json.encode(key.value));
          Sentence d = new Sentence();
          d.file = data['file'] ?? "";
          d.text = data['text'] ?? "";
          d.cat = load;
          d.isFav = 0;

          dbRef.insert(d);
          // followUps.add(d);
        }

        if (keys.length > 0) {
          List<Sentence> wordsList = await dbRef.getWords();
          followUps = wordsList.where((element) => element.cat == load).toList();
          SharedPref.saveBool(main, true);
        }
      });
    }
    print(followUps.length);

    return followUps;
  }

  Future<List<Sentence>> getSentences(String load, String main, String cat) async {
    print(load);

    List<Sentence> sentences = [];

    await _database.ref().child(main).child(load).child(cat).orderByKey().once().then((DatabaseEvent snap) {
      var keys = snap.snapshot.children;
      // var data = snap.value;
      sentences.clear();

      for (var key in keys) {
        Sentence d = new Sentence();
        d.file = key.child('file').toString();
        d.text = key.child('text').toString();

        sentences.add(d);
      }
    });
    return sentences;
  }

// Future<UserM> getUser(String userID) async {
//   return await _database
//       .ref()
//       .child("UserNode")
//       .child(userID)
//       .once()
//       .then((DatabaseEvent snap) {
//     return UserM.fromSnapshot(snap);
//   }).catchError((error) {
//     print('error: $error');
//     return null;
//   });
//   // return users[0];
// }
//
// Future<void> setUserImei(String imei, String model, String userID) async {
//   Map<String, String> imeiVal = new Map();
//   imeiVal["imei"] = imei;
//   imeiVal["model"] = model;
//   return await _database
//       .ref()
//       .child("UserNode")
//       .child(userID)
//       .update(imeiVal);
//   // return users[0];
// }
}
